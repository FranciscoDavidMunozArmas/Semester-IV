<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./static/styles/id_css.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<body>

    <?php
    include './views/navigation.php';
    ?>

    <?php
    $mvc = new Controller();
    $mvc->get_page();
    ?>
    </div>

</body>

</html>

<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_mysql";
$table = "user";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error de conexion");
}

if (isset($_REQUEST['create'])) {
    $name = $_REQUEST['name'];
    $surname = $_REQUEST['surname'];
    $user_id = $_REQUEST['user_id'];
    $sql = "INSERT INTO " . $table . "(name, surname, user_id)
        VALUES ('$name', '$surname', '$user_id')";
}

if (isset($_REQUEST['update'])) {
    $name = $_REQUEST['name'];
    $surname = $_REQUEST['surname'];
    $user_id = $_REQUEST['user_id'];
    $id = $_REQUEST['row_id'];

    $sql = "UPDATE " . $table . " SET name='" . $name . "',surname='" .
        $surname . "', user_id='" . $user_id . "' WHERE id=" . $id;
}

if (isset($_REQUEST['delete'])) {
    $id = $_REQUEST['row_id'];
    $sql = "DELETE FROM " . $table . " WHERE id=" . $id;
}

if (isset($_REQUEST['show'])) {
    $sql = "SELECT * FROM " . $table;
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        echo "<div class='container'><div class='table-responsive'><table class='table'><thead><tr><th>Row Id</th><th>Name</th><th>Surname</th><th>ID</th></tr></thead><tbody id='user_table'>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td> " . $row["id"]      . " </td>";
            echo "<td> " . $row["name"]     . " </td>";
            echo "<td> " . $row["surname"]   . " </td>";
            echo "<td> " . $row["user_id"]       . " </td>";
            echo "</tr>";
        }
        echo "</tbody></table></div></div>";
        return;
    }
}

if ($conn->query($sql) != true) {
    echo "<p id='mensaje2' style='color:blue;'>" . "Error: revise " . $sql . "<br>" . $conn->error;
}
$conn->close();



?>