<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="./index.php?action=home">Prueba</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="active"><a href="./index.php?action=home">Home</a></li>
            <!-- <li><a href="./user_creator.html">Check your ID</a></li>
            <li><a href="./set_alarm.html">Alarm</a></li> -->
        </ul>
    </div>
</nav>