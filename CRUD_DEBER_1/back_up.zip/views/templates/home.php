<div class="container">
    <form id="form" method="post">
        <div class="form_container">
            <div>
                <input type="text" id="name" placeholder="Name" name="name">
            </div>
            <div>
                <input type="text" id="surname" placeholder="Surname" name="surname">
            </div>
            <div class="id_container">
                <input type="text" id="ID" placeholder="ID" name="user_id">
                <br>
                <label for="check_id" id="check_label"></label>
            </div>
            <div class="btn_form">
                <input type="submit" id="btn_check_id" name="create" value="Save">
            </div>
        </div>
    </form>
</div>

<div class="container">
    <form id="form" method="post">
        <div class="form_container">
            <div>
                <input type="numeric" placeholder="Row ID" name="row_id">
            </div>
            <div class="btn_form">
                <input type="submit" id="btn_check_id" name="delete" value="Delete">
                <input type="submit" id="btn_check_id" name="update" value="Update">
                <input type="submit" id="btn_check_id" name="show" value="Show">
            </div>
        </div>
    </form>
</div>

<!-- <script type="javascript" src="./static/js/id_checker.js"></script> -->