<?php
$result = Form_Controller::select(null, null);
?>

<div class="container">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Surname</th>
                    <th>ID</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="user_table">
                <?php foreach ($result as $key => $value) : ?>

                    <tr>
                        <td><?php echo $value['name'] ?></td>
                        <td><?php echo $value['surname'] ?></td>
                        <td><?php echo $value['user_id'] ?></td>
                        <td>
                            <form method="post">
                                <input type="hidden" value="<?php echo $value["id"] ?>" name="delete">
                                <button type=" submit" class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
                                <?php
                                $delete = new Form_Controller();
                                $delete->delete();
                                ?>
                            </form>
                        </td>
                    </tr>

                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</div>