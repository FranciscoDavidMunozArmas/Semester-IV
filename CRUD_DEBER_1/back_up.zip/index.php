<?php

require_once './controller/controller.php';
require_once './controller/link.php';

$mvc = new Controller();
$mvc->get_template();
