<?php
class Form_Controller
{
    public static function create()
    {
        if (
            isset($_POST["name"]) &&
            isset($_POST["surname"]) &&
            isset($_POST["user_id"])
        ) {

            $table = "user";
            $data = array(
                "user" => $_POST["name"],
                "surname" => $_POST["surname"],
                "user_id" => $_POST["user_id"]
            );
            $response = Model::create($table, $data);
            return $response;
        }
    }

    public static function select($column, $value)
    {
        $table = "user";
        $response = Model::read($table, null, null);
        return $response;
    }

    public static function update()
    {
        if (
            isset($_POST["name"]) &&
            isset($_POST["surname"]) &&
            isset($_POST["user_id"])
        ) {

            $table = "user";
            $data = array(
                "user" => $_POST["name"],
                "surname" => $_POST["surname"],
                "user_id" => $_POST["user_id"]
            );
            $response = Model::update($table, $data);
            return $response;
        }
    }

    public static function delete()
    {
        if (isset($_POST["delete"])) {

            $table = "user";
            $data = $_POST["delete"];
            $response = Model::delete($table, $data);
            return $response;
        }
    }
}
